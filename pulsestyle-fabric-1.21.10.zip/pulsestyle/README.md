# Pulse Style — клиентский Fabric-мод (Minecraft 1.21.10)

Тёмное меню настроек + PvP-визуалы в духе Pulse Visuals:

| Что            | Где настраивается                                              |
|----------------|----------------------------------------------------------------|
| PvP HUD        | вкладка **HUD**: FPS, CPS, ping, координаты, броня, позиция    |
| Малый прицел   | вкладка **Crosshair**: размер, зазор, точка, обводка, кулдаун  |
| Меньше огня    | вкладка **Effects**: Vanilla / Low / Off + насколько опустить  |
| Тёмный инвентарь | вкладка **Effects**: затемнение экранов инвентаря            |
| Акцентный цвет | вкладка **Theme**                                              |

Открыть меню: **Right Shift** (меняется в Настройки → Управление → Pulse Style).
Настройки лежат в `config/pulsestyle.json`.

## Сборка
Нужны Java 21 и Gradle 8.14+ (или gradle wrapper из шаблона).

1. Если нет `gradlew`: сгенерируй шаблон на https://fabricmc.net/develop (1.21.10),
   скопируй из него `gradlew`, `gradlew.bat` и папку `gradle/` в корень этого проекта.
   Заодно сверь номера версий с `gradle.properties`.
2. `./gradlew build`
3. Готовый мод: `build/libs/pulsestyle-1.0.0.jar` → в папку `mods` вместе с **Fabric API**.

Для запуска из IDE: `./gradlew runClient`.

## Если не собирается
Код написан под 1.21.10 (Yarn). Самые «хрупкие» места, которые меняются между версиями:
- `PulseStyleClient`: `KeyBinding.Category.create(...)`, `HudElementRegistry.replaceElement(...)`
- `FireOverlayMixin`: имя метода `renderFireOverlay` и вызов `MatrixStack.translate(FFF)V`
- `PulseWidgets`: сигнатура `renderWidget(...)`

## Структура
- `PulseStyleClient` — вход, кнопка, регистрация HUD/прицела/затемнения
- `config/PulseConfig` — настройки + JSON
- `ui/PulseMenuScreen`, `ui/PulseWidgets`, `ui/PulseTheme` — меню и стиль
- `hud/PulseHud`, `hud/PulseCrosshair` — HUD и прицел
- `mixin/FireOverlayMixin` — огонь на экране

## Ограничение
«Тёмный инвентарь» здесь — это затемнение экрана. Полная перерисовка панелей (прозрачные
слоты, свои рамки) делается ресурспаком с текстурами GUI.
