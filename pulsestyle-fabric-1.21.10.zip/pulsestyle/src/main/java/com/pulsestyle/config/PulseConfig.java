package com.pulsestyle.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;

/** Все настройки мода. Хранятся в config/pulsestyle.json. */
public final class PulseConfig {
    public enum FireMode { VANILLA, LOW, OFF }

    // ---- HUD ----
    public boolean hudEnabled = true;
    public boolean showFps = true;
    public boolean showCps = true;
    public boolean showPing = true;
    public boolean showCoords = false;
    public boolean showArmor = true;
    public int hudOpacity = 55;   // % непрозрачности фона панели
    public int hudX = 0;          // позиция в % ширины экрана
    public int hudY = 2;          // позиция в % высоты экрана

    // ---- Прицел ----
    public boolean crosshairEnabled = true;
    public boolean crosshairDot = false;
    public boolean crosshairOutline = true;
    public boolean crosshairEnemyColor = true;
    public boolean crosshairCooldown = true;
    public int crosshairSize = 3;
    public int crosshairGap = 2;
    public int crosshairThickness = 1;

    // ---- Эффекты ----
    public FireMode fireMode = FireMode.LOW;
    public int fireLowering = 25;     // на сколько опустить огонь (сотые доли блока)
    public boolean darkScreens = true;
    public int darkOpacity = 40;

    // ---- Тема ----
    public int accentIndex = 0;

    // ------------------------------------------------------------------

    private static final Logger LOGGER = LoggerFactory.getLogger("pulsestyle");
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("pulsestyle.json");
    private static PulseConfig instance = new PulseConfig();

    public static PulseConfig get() {
        return instance;
    }

    public static void reset() {
        instance = new PulseConfig();
    }

    public static void load() {
        if (!Files.exists(FILE)) {
            save();
            return;
        }
        try (Reader reader = Files.newBufferedReader(FILE)) {
            PulseConfig loaded = GSON.fromJson(reader, PulseConfig.class);
            if (loaded != null) {
                loaded.sanitize();
                instance = loaded;
            }
        } catch (Exception e) {
            LOGGER.warn("Could not read pulsestyle.json, using defaults", e);
        }
    }

    public static void save() {
        try {
            Files.createDirectories(FILE.getParent());
            try (Writer writer = Files.newBufferedWriter(FILE)) {
                GSON.toJson(instance, writer);
            }
        } catch (IOException e) {
            LOGGER.warn("Could not save pulsestyle.json", e);
        }
    }

    private void sanitize() {
        hudOpacity = clamp(hudOpacity, 0, 100);
        hudX = clamp(hudX, 0, 100);
        hudY = clamp(hudY, 0, 100);
        crosshairSize = clamp(crosshairSize, 0, 12);
        crosshairGap = clamp(crosshairGap, 0, 10);
        crosshairThickness = clamp(crosshairThickness, 1, 4);
        fireLowering = clamp(fireLowering, 0, 60);
        darkOpacity = clamp(darkOpacity, 0, 80);
        if (fireMode == null) fireMode = FireMode.LOW;
    }

    private static int clamp(int v, int min, int max) {
        return Math.max(min, Math.min(max, v));
    }
}
