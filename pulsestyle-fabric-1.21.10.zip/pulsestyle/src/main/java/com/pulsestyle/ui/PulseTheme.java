package com.pulsestyle.ui;

import com.pulsestyle.config.PulseConfig;
import net.minecraft.client.gui.DrawContext;

/** Палитра и мелкие хелперы отрисовки. Все цвета в формате ARGB (0xAARRGGBB). */
public final class PulseTheme {
    public static final int[] ACCENTS = {
            0xFF4DA3FF, 0xFFA66BFF, 0xFFFF6BB5, 0xFF4DE0A0, 0xFFFF5E5E, 0xFFFFFFFF
    };
    public static final String[] ACCENT_NAMES = { "Blue", "Purple", "Pink", "Mint", "Red", "White" };

    private PulseTheme() {}

    public static int accent() {
        return ACCENTS[Math.floorMod(PulseConfig.get().accentIndex, ACCENTS.length)];
    }

    public static int argb(int alpha, int rgb) {
        return (alpha << 24) | (rgb & 0xFFFFFF);
    }

    /** Прямоугольник со срезанными углами (три непересекающихся полосы, чтобы альфа не накладывалась дважды). */
    public static void roundedFill(DrawContext ctx, int x1, int y1, int x2, int y2, int color) {
        ctx.fill(x1 + 1, y1, x2 - 1, y1 + 1, color);
        ctx.fill(x1, y1 + 1, x2, y2 - 1, color);
        ctx.fill(x1 + 1, y2 - 1, x2 - 1, y2, color);
    }
}
