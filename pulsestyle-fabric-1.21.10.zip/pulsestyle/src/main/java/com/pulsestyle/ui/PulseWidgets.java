package com.pulsestyle.ui;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.text.Text;

import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.IntConsumer;
import java.util.function.IntFunction;
import java.util.function.IntSupplier;

/**
 * Виджеты в стиле меню. Наследуемся от ButtonWidget / SliderWidget и переопределяем
 * только отрисовку: логика кликов и перетаскивания остаётся ванильной.
 */
public final class PulseWidgets {
    private static final int TEXT = 0xFFE6EAF0;
    private static final int MUTED = 0xFF8A94A6;
    private static final int OFF = 0xFF3A404C;

    private PulseWidgets() {}

    private static TextRenderer tr() {
        return MinecraftClient.getInstance().textRenderer;
    }

    private static int bg(boolean hovered) {
        return hovered ? 0xD0262C38 : 0xC0171B24;
    }

    // ------------------------------------------------------------------ Toggle
    public static class Toggle extends ButtonWidget {
        private final BooleanSupplier get;

        public Toggle(int x, int y, int w, int h, String label, BooleanSupplier get, Consumer<Boolean> set) {
            super(x, y, w, h, Text.literal(label), b -> set.accept(!get.getAsBoolean()), DEFAULT_NARRATION_SUPPLIER);
            this.get = get;
        }

        @Override
        public void renderWidget(DrawContext ctx, int mouseX, int mouseY, float delta) {
            int x = getX(), y = getY(), w = getWidth(), h = getHeight();
            boolean on = get.getAsBoolean();

            PulseTheme.roundedFill(ctx, x, y, x + w, y + h, bg(isHovered()));
            ctx.drawText(tr(), getMessage(), x + 6, y + (h - 8) / 2, TEXT, false);

            int sw = 22, sh = 10;
            int sx = x + w - sw - 6, sy = y + (h - sh) / 2;
            PulseTheme.roundedFill(ctx, sx, sy, sx + sw, sy + sh, on ? PulseTheme.accent() : OFF);
            int kx = on ? sx + sw - sh + 1 : sx + 1;
            ctx.fill(kx, sy + 1, kx + sh - 2, sy + sh - 1, 0xFFFFFFFF);
        }
    }

    // ------------------------------------------------------------------ Slider
    public static class Slider extends SliderWidget {
        private final String label;
        private final String suffix;
        private final int min;
        private final int max;
        private final IntConsumer set;

        public Slider(int x, int y, int w, int h, String label, int min, int max, String suffix,
                      int current, IntConsumer set) {
            super(x, y, w, h, Text.empty(), (current - min) / (double) (max - min));
            this.label = label;
            this.suffix = suffix;
            this.min = min;
            this.max = max;
            this.set = set;
        }

        private int current() {
            return min + (int) Math.round(value * (max - min));
        }

        @Override
        protected void updateMessage() {
            // текст рисуем сами в renderWidget
        }

        @Override
        protected void applyValue() {
            set.accept(current());
        }

        @Override
        public void renderWidget(DrawContext ctx, int mouseX, int mouseY, float delta) {
            int x = getX(), y = getY(), w = getWidth(), h = getHeight();
            TextRenderer tr = tr();

            PulseTheme.roundedFill(ctx, x, y, x + w, y + h, bg(isHovered()));
            String val = current() + suffix;
            ctx.drawText(tr, label, x + 6, y + 3, TEXT, false);
            ctx.drawText(tr, val, x + w - 6 - tr.getWidth(val), y + 3, MUTED, false);

            int t1 = x + 4, t2 = x + w - 4, ty = y + h - 5;
            ctx.fill(t1, ty, t2, ty + 2, OFF);
            int fx = t1 + (int) ((t2 - t1) * value);
            ctx.fill(t1, ty, fx, ty + 2, PulseTheme.accent());
            ctx.fill(fx - 1, ty - 2, fx + 2, ty + 4, 0xFFFFFFFF);
        }
    }

    // ------------------------------------------------------------------ Cycle
    public static class Cycle extends ButtonWidget {
        private final IntSupplier get;
        private final IntFunction<String> names;
        private final IntSupplier swatch; // может быть null

        public Cycle(int x, int y, int w, int h, String label, int count, IntSupplier get, IntConsumer set,
                     IntFunction<String> names, IntSupplier swatch) {
            super(x, y, w, h, Text.literal(label), b -> set.accept((get.getAsInt() + 1) % count),
                    DEFAULT_NARRATION_SUPPLIER);
            this.get = get;
            this.names = names;
            this.swatch = swatch;
        }

        @Override
        public void renderWidget(DrawContext ctx, int mouseX, int mouseY, float delta) {
            int x = getX(), y = getY(), w = getWidth(), h = getHeight();
            TextRenderer tr = tr();

            PulseTheme.roundedFill(ctx, x, y, x + w, y + h, bg(isHovered()));
            ctx.drawText(tr, getMessage(), x + 6, y + (h - 8) / 2, TEXT, false);

            int right = x + w - 6;
            if (swatch != null) {
                ctx.fill(right - 8, y + (h - 8) / 2, right, y + (h - 8) / 2 + 8, swatch.getAsInt());
                right -= 12;
            }
            String val = names.apply(get.getAsInt());
            ctx.drawText(tr, val, right - tr.getWidth(val), y + (h - 8) / 2, PulseTheme.accent(), false);
        }
    }

    // ------------------------------------------------------------------ Button
    public static class Button extends ButtonWidget {
        public Button(int x, int y, int w, int h, String label, Runnable action) {
            super(x, y, w, h, Text.literal(label), b -> action.run(), DEFAULT_NARRATION_SUPPLIER);
        }

        @Override
        public void renderWidget(DrawContext ctx, int mouseX, int mouseY, float delta) {
            int x = getX(), y = getY(), w = getWidth(), h = getHeight();
            TextRenderer tr = tr();
            PulseTheme.roundedFill(ctx, x, y, x + w, y + h, bg(isHovered()));
            ctx.fill(x + 1, y + h - 1, x + w - 1, y + h, PulseTheme.accent());
            ctx.drawText(tr, getMessage(), x + (w - tr.getWidth(getMessage())) / 2, y + (h - 8) / 2, TEXT, false);
        }
    }

    // ------------------------------------------------------------------ Tab (боковая вкладка)
    public static class Tab extends ButtonWidget {
        private final BooleanSupplier selected;

        public Tab(int x, int y, int w, int h, String label, BooleanSupplier selected, Runnable onSelect) {
            super(x, y, w, h, Text.literal(label), b -> onSelect.run(), DEFAULT_NARRATION_SUPPLIER);
            this.selected = selected;
        }

        @Override
        public void renderWidget(DrawContext ctx, int mouseX, int mouseY, float delta) {
            int x = getX(), y = getY(), w = getWidth(), h = getHeight();
            boolean sel = selected.getAsBoolean();

            if (sel) {
                PulseTheme.roundedFill(ctx, x, y, x + w, y + h, 0xD0222836);
                ctx.fill(x, y + 3, x + 2, y + h - 3, PulseTheme.accent());
            } else if (isHovered()) {
                PulseTheme.roundedFill(ctx, x, y, x + w, y + h, 0x90181D27);
            }
            ctx.drawText(tr(), getMessage(), x + 10, y + (h - 8) / 2, sel ? 0xFFFFFFFF : MUTED, false);
        }
    }
}
