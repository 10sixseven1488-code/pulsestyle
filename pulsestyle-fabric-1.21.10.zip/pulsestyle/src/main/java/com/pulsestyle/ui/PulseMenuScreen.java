package com.pulsestyle.ui;

import com.pulsestyle.config.PulseConfig;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.IntConsumer;
import java.util.function.IntSupplier;

/** Главное меню мода: тёмная панель, вкладки слева, настройки справа. */
public class PulseMenuScreen extends Screen {
    private static final int PW = 424;
    private static final int PH = 190;
    private static final int SIDEBAR = 84;
    private static final int ROW = 24;
    private static final String[] TABS = { "HUD", "Crosshair", "Effects", "Theme" };
    private static int lastTab = 0;

    private final Screen parent;
    private final long openedAt = System.currentTimeMillis();
    private int px, py, cx, cy, colW, slot;

    public PulseMenuScreen(Screen parent) {
        super(Text.literal("Pulse Style"));
        this.parent = parent;
    }

    private static PulseConfig cfg() {
        return PulseConfig.get();
    }

    // ------------------------------------------------------------------ layout
    @Override
    protected void init() {
        px = (width - PW) / 2;
        py = (height - PH) / 2;

        for (int i = 0; i < TABS.length; i++) {
            final int idx = i;
            addDrawableChild(new PulseWidgets.Tab(px + 8, py + 36 + i * 24, SIDEBAR - 16, 20, TABS[i],
                    () -> lastTab == idx, () -> { lastTab = idx; clearAndInit(); }));
        }

        cx = px + SIDEBAR + 10;
        cy = py + 34;
        colW = (PW - SIDEBAR - 20 - 8) / 2;
        slot = 0;

        switch (lastTab) {
            case 0 -> hudTab();
            case 1 -> crosshairTab();
            case 2 -> effectsTab();
            default -> themeTab();
        }
    }

    private int slotX() { return cx + (slot % 2) * (colW + 8); }
    private int slotY() { return cy + (slot / 2) * ROW; }

    private void toggle(String label, BooleanSupplier get, Consumer<Boolean> set) {
        addDrawableChild(new PulseWidgets.Toggle(slotX(), slotY(), colW, 20, label, get, set));
        slot++;
    }

    private void slider(String label, int min, int max, String suffix, IntSupplier get, IntConsumer set) {
        addDrawableChild(new PulseWidgets.Slider(slotX(), slotY(), colW, 20, label, min, max, suffix,
                get.getAsInt(), set));
        slot++;
    }

    // ------------------------------------------------------------------ tabs
    private void hudTab() {
        toggle("HUD enabled", () -> cfg().hudEnabled, v -> cfg().hudEnabled = v);
        toggle("Show FPS", () -> cfg().showFps, v -> cfg().showFps = v);
        toggle("Show CPS", () -> cfg().showCps, v -> cfg().showCps = v);
        toggle("Show ping", () -> cfg().showPing, v -> cfg().showPing = v);
        toggle("Coordinates", () -> cfg().showCoords, v -> cfg().showCoords = v);
        toggle("Armor status", () -> cfg().showArmor, v -> cfg().showArmor = v);
        slider("Panel opacity", 0, 100, "%", () -> cfg().hudOpacity, v -> cfg().hudOpacity = v);
        slider("Position X", 0, 100, "%", () -> cfg().hudX, v -> cfg().hudX = v);
        slider("Position Y", 0, 100, "%", () -> cfg().hudY, v -> cfg().hudY = v);
    }

    private void crosshairTab() {
        toggle("Custom crosshair", () -> cfg().crosshairEnabled, v -> cfg().crosshairEnabled = v);
        toggle("Center dot", () -> cfg().crosshairDot, v -> cfg().crosshairDot = v);
        toggle("Outline", () -> cfg().crosshairOutline, v -> cfg().crosshairOutline = v);
        toggle("Red on enemy", () -> cfg().crosshairEnemyColor, v -> cfg().crosshairEnemyColor = v);
        toggle("Cooldown bar", () -> cfg().crosshairCooldown, v -> cfg().crosshairCooldown = v);
        slider("Arm length", 0, 12, "px", () -> cfg().crosshairSize, v -> cfg().crosshairSize = v);
        slider("Gap", 0, 10, "px", () -> cfg().crosshairGap, v -> cfg().crosshairGap = v);
        slider("Thickness", 1, 4, "px", () -> cfg().crosshairThickness, v -> cfg().crosshairThickness = v);
    }

    private void effectsTab() {
        String[] modes = { "Vanilla", "Low", "Off" };
        addDrawableChild(new PulseWidgets.Cycle(slotX(), slotY(), colW, 20, "Fire overlay", modes.length,
                () -> cfg().fireMode.ordinal(),
                i -> cfg().fireMode = PulseConfig.FireMode.values()[i],
                i -> modes[i], null));
        slot++;
        slider("Fire lowering", 0, 60, "%", () -> cfg().fireLowering, v -> cfg().fireLowering = v);
        toggle("Dark inventory tint", () -> cfg().darkScreens, v -> cfg().darkScreens = v);
        slider("Tint strength", 0, 80, "%", () -> cfg().darkOpacity, v -> cfg().darkOpacity = v);
    }

    private void themeTab() {
        addDrawableChild(new PulseWidgets.Cycle(slotX(), slotY(), colW, 20, "Accent color",
                PulseTheme.ACCENTS.length,
                () -> cfg().accentIndex,
                i -> cfg().accentIndex = i,
                i -> PulseTheme.ACCENT_NAMES[i],
                PulseTheme::accent));
        slot++;
        addDrawableChild(new PulseWidgets.Button(slotX(), slotY(), colW, 20, "Reset all settings",
                () -> { PulseConfig.reset(); clearAndInit(); }));
        slot++;
    }

    // ------------------------------------------------------------------ rendering
    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        float fade = Math.min(1f, (System.currentTimeMillis() - openedAt) / 150f);
        ctx.fill(0, 0, width, height, PulseTheme.argb((int) (0x99 * fade), 0x060810));

        int accent = PulseTheme.accent();
        PulseTheme.roundedFill(ctx, px - 1, py - 1, px + PW + 1, py + PH + 1, PulseTheme.argb(0x55, accent));
        PulseTheme.roundedFill(ctx, px, py, px + PW, py + PH, 0xF00C0F15);
        ctx.fill(px + SIDEBAR, py + 8, px + SIDEBAR + 1, py + PH - 8, 0x22FFFFFF);

        ctx.drawText(textRenderer, "PULSE", px + 10, py + 12, accent, false);
        ctx.drawText(textRenderer, "STYLE", px + 10 + textRenderer.getWidth("PULSE "), py + 12, 0xFFFFFFFF, false);
        ctx.drawText(textRenderer, TABS[lastTab], cx, py + 12, 0xFFFFFFFF, false);
        ctx.fill(cx, py + 24, px + PW - 10, py + 25, 0x22FFFFFF);

        ctx.drawText(textRenderer, "Menu key: Right Shift (change in Controls)  |  Esc: close",
                cx, py + PH - 14, 0xFF5E6778, false);

        super.render(ctx, mouseX, mouseY, delta);
    }

    /** Свой фон рисуется в render(), ванильное размытие не нужно. */
    @Override
    public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) {
    }

    @Override
    public boolean shouldPause() {
        return false; // игра идёт, прицел и HUD видны как превью
    }

    @Override
    public void close() {
        if (client != null) client.setScreen(parent);
    }

    @Override
    public void removed() {
        PulseConfig.save();
    }
}
