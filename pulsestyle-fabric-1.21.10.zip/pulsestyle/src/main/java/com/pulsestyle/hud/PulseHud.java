package com.pulsestyle.hud;

import com.pulsestyle.config.PulseConfig;
import com.pulsestyle.ui.PulseTheme;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;

/** Компактный PvP HUD: FPS / CPS / ping / координаты + состояние брони. */
public final class PulseHud {
    private static final ArrayDeque<Long> CLICKS = new ArrayDeque<>();
    private static final EquipmentSlot[] ARMOR = {
            EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET
    };
    private static boolean wasDown;

    private PulseHud() {}

    public static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;

        trackClicks(mc);

        PulseConfig cfg = PulseConfig.get();
        if (!cfg.hudEnabled || mc.options.hudHidden) return;

        TextRenderer tr = mc.textRenderer;

        // --- строки статистики: {название, значение}
        List<String[]> rows = new ArrayList<>();
        if (cfg.showFps) rows.add(new String[] { "FPS", String.valueOf(mc.getCurrentFps()) });
        if (cfg.showCps) rows.add(new String[] { "CPS", String.valueOf(CLICKS.size()) });
        if (cfg.showPing) rows.add(new String[] { "Ping", ping(mc) });
        if (cfg.showCoords) {
            rows.add(new String[] { "XYZ",
                    mc.player.getBlockX() + " " + mc.player.getBlockY() + " " + mc.player.getBlockZ() });
        }

        // --- броня
        List<ItemStack> armor = new ArrayList<>();
        if (cfg.showArmor) {
            for (EquipmentSlot slot : ARMOR) {
                ItemStack s = mc.player.getEquippedStack(slot);
                if (!s.isEmpty()) armor.add(s);
            }
        }
        if (rows.isEmpty() && armor.isEmpty()) return;

        // --- размеры
        final int pad = 5, rowH = 11, bar = 2, between = 3, armorRowH = 18, armorGap = 1;
        int labelW = 0, valueW = 0;
        for (String[] r : rows) {
            labelW = Math.max(labelW, tr.getWidth(r[0]));
            valueW = Math.max(valueW, tr.getWidth(r[1]));
        }
        int statsW = rows.isEmpty() ? 0 : bar + pad * 2 + labelW + 10 + valueW;
        int statsH = rows.isEmpty() ? 0 : pad * 2 - 2 + rows.size() * rowH;
        int armorW = armor.isEmpty() ? 0 : bar + pad + 16 + 4 + tr.getWidth("100%") + pad;
        int armorH = armor.isEmpty() ? 0 : armor.size() * armorRowH + (armor.size() - 1) * armorGap;

        int totalW = Math.max(statsW, armorW);
        int totalH = statsH + (statsH > 0 && armorH > 0 ? between : 0) + armorH;

        int sw = ctx.getScaledWindowWidth();
        int sh = ctx.getScaledWindowHeight();
        int x = 4 + (int) ((sw - totalW - 8) * cfg.hudX / 100f);
        int y = 4 + (int) ((sh - totalH - 8) * cfg.hudY / 100f);

        int accent = PulseTheme.accent();
        int bg = PulseTheme.argb(cfg.hudOpacity * 255 / 100, 0x0B0E14);

        // --- панель статистики
        if (!rows.isEmpty()) {
            PulseTheme.roundedFill(ctx, x, y, x + totalW, y + statsH, bg);
            ctx.fill(x, y + 1, x + bar, y + statsH - 1, accent);
            int ty = y + pad - 1;
            for (String[] r : rows) {
                ctx.drawText(tr, r[0], x + bar + pad, ty, 0xFF8A94A6, false);
                ctx.drawText(tr, r[1], x + totalW - pad - tr.getWidth(r[1]), ty, 0xFFFFFFFF, false);
                ty += rowH;
            }
        }

        // --- панель брони
        int ay = y + statsH + (statsH > 0 && armorH > 0 ? between : 0);
        for (ItemStack stack : armor) {
            PulseTheme.roundedFill(ctx, x, ay, x + totalW, ay + armorRowH, bg);
            ctx.fill(x, ay + 1, x + bar, ay + armorRowH - 1, accent);
            ctx.drawItem(stack, x + bar + pad - 1, ay + 1);
            if (stack.isDamageable()) {
                int max = stack.getMaxDamage();
                int percent = Math.max(0, Math.round(100f * (max - stack.getDamage()) / max));
                int color = percent > 50 ? 0xFF6BE38E : percent > 25 ? 0xFFFFD166 : 0xFFFF6B6B;
                ctx.drawText(tr, percent + "%", x + bar + pad + 16 + 4, ay + (armorRowH - 8) / 2, color, false);
            }
            ay += armorRowH + armorGap;
        }
    }

    private static String ping(MinecraftClient mc) {
        if (mc.getNetworkHandler() == null) return "-";
        PlayerListEntry entry = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
        return entry == null ? "-" : entry.getLatency() + " ms";
    }

    /** CPS: считаем нажатия кнопки атаки (по фронту нажатия) за последнюю секунду. */
    private static void trackClicks(MinecraftClient mc) {
        long now = System.currentTimeMillis();
        boolean down = mc.currentScreen == null && mc.options.attackKey.isPressed();
        if (down && !wasDown) CLICKS.addLast(now);
        wasDown = down;
        while (!CLICKS.isEmpty() && now - CLICKS.peekFirst() > 1000) CLICKS.pollFirst();
    }
}
