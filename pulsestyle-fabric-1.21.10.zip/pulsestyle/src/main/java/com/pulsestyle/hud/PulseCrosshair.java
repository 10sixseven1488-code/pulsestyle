package com.pulsestyle.hud;

import com.pulsestyle.config.PulseConfig;
import com.pulsestyle.ui.PulseTheme;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.util.hit.HitResult;

import java.util.ArrayList;
import java.util.List;

/** Маленький минималистичный прицел вместо ванильного. */
public final class PulseCrosshair {
    private PulseCrosshair() {}

    public static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || !mc.options.getPerspective().isFirstPerson()) return;

        PulseConfig c = PulseConfig.get();
        int cx = (ctx.getScaledWindowWidth() - 1) / 2;
        int cy = (ctx.getScaledWindowHeight() - 1) / 2;
        int t = c.crosshairThickness;
        int half = t / 2;
        int size = c.crosshairSize;
        int gap = c.crosshairGap;

        int color = 0xFFFFFFFF;
        if (c.crosshairEnemyColor && mc.crosshairTarget != null
                && mc.crosshairTarget.getType() == HitResult.Type.ENTITY) {
            color = 0xFFFF4D4D;
        }

        // {x1, y1, x2, y2}
        List<int[]> rects = new ArrayList<>();
        rects.add(new int[] { cx - half - gap - size, cy - half, cx - half - gap, cy - half + t });          // лево
        rects.add(new int[] { cx - half + t + gap, cy - half, cx - half + t + gap + size, cy - half + t });  // право
        rects.add(new int[] { cx - half, cy - half - gap - size, cx - half + t, cy - half - gap });          // верх
        rects.add(new int[] { cx - half, cy - half + t + gap, cx - half + t, cy - half + t + gap + size });  // низ
        if (c.crosshairDot) rects.add(new int[] { cx - half, cy - half, cx - half + t, cy - half + t });

        // сначала все обводки, потом все заливки — чтобы обводка не перекрывала соседние линии
        if (c.crosshairOutline) {
            for (int[] r : rects) ctx.fill(r[0] - 1, r[1] - 1, r[2] + 1, r[3] + 1, 0xB0000000);
        }
        for (int[] r : rects) ctx.fill(r[0], r[1], r[2], r[3], color);

        // индикатор кулдауна атаки
        if (c.crosshairCooldown) {
            float progress = mc.player.getAttackCooldownProgress(0.0F);
            if (progress < 1.0F) {
                int bw = Math.max(9, (size + gap) * 2 + t);
                int bx = cx - bw / 2;
                int by = cy + half + gap + size + 5;
                ctx.fill(bx - 1, by - 1, bx + bw + 1, by + 2, 0xB0000000);
                ctx.fill(bx, by, bx + (int) (bw * progress), by + 1, PulseTheme.accent());
            }
        }
    }
}
