package com.pulsestyle.mixin;

import com.pulsestyle.config.PulseConfig;
import net.minecraft.client.gui.hud.InGameOverlayRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** «Reduced fire»: опускаем огонь на экране вниз или скрываем совсем. */
@Mixin(InGameOverlayRenderer.class)
public abstract class FireOverlayMixin {

    @Inject(method = "renderFireOverlay", at = @At("HEAD"), cancellable = true)
    private static void pulsestyle$hideFire(CallbackInfo ci) {
        if (PulseConfig.get().fireMode == PulseConfig.FireMode.OFF) {
            ci.cancel();
        }
    }

    /** В ваниле огонь сдвигается на translate(±0.24, -0.3, 0): меняем Y (индекс 1). */
    @ModifyArg(
            method = "renderFireOverlay",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/util/math/MatrixStack;translate(FFF)V"),
            index = 1
    )
    private static float pulsestyle$lowerFire(float y) {
        PulseConfig c = PulseConfig.get();
        return c.fireMode == PulseConfig.FireMode.LOW ? y - c.fireLowering / 100.0F : y;
    }
}
