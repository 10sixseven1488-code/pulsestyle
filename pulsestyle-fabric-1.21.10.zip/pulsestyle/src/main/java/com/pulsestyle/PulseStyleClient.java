package com.pulsestyle;

import com.pulsestyle.config.PulseConfig;
import com.pulsestyle.hud.PulseCrosshair;
import com.pulsestyle.hud.PulseHud;
import com.pulsestyle.ui.PulseMenuScreen;
import com.pulsestyle.ui.PulseTheme;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public class PulseStyleClient implements ClientModInitializer {
    public static final String MOD_ID = "pulsestyle";

    private static KeyBinding openMenu;

    @Override
    public void onInitializeClient() {
        PulseConfig.load();

        // --- клавиша открытия меню (Right Shift по умолчанию)
        KeyBinding.Category category = KeyBinding.Category.create(Identifier.of(MOD_ID, "main"));
        openMenu = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.pulsestyle.menu", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, category));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openMenu.wasPressed()) {
                if (client.currentScreen == null) {
                    client.setScreen(new PulseMenuScreen(null));
                }
            }
        });

        // --- HUD поверх всех ванильных элементов
        HudElementRegistry.addLast(Identifier.of(MOD_ID, "hud"), PulseHud::render);

        // --- подмена ванильного прицела (если выключен в меню — рисуется ванильный)
        HudElementRegistry.replaceElement(VanillaHudElements.CROSSHAIR, original -> (ctx, tickCounter) -> {
            if (PulseConfig.get().crosshairEnabled) {
                PulseCrosshair.render(ctx, tickCounter);
            } else {
                original.render(ctx, tickCounter);
            }
        });

        // --- тёмное затемнение инвентарей и контейнеров
        ScreenEvents.AFTER_INIT.register((client, screen, scaledWidth, scaledHeight) -> {
            if (screen instanceof HandledScreen<?>) {
                ScreenEvents.beforeRender(screen).register((s, ctx, mouseX, mouseY, delta) -> {
                    PulseConfig c = PulseConfig.get();
                    if (c.darkScreens && c.darkOpacity > 0) {
                        ctx.fill(0, 0, s.width, s.height,
                                PulseTheme.argb(c.darkOpacity * 255 / 100, 0x05070C));
                    }
                });
            }
        });
    }
}
